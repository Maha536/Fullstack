export class Product{
    id : number;
    name : String;
    category : String;
    cost : Number;

    constructor(id,name,category,cost){
        this.id = id;
        this.name =name;
        this.category=category;
        this.cost=cost;
    }

 
}