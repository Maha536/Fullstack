package com.cts.training.bootproduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootproductApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootproductApplication.class, args);
	}

}
