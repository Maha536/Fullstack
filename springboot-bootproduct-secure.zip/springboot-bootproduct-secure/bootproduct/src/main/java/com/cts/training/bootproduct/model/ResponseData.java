package com.cts.training.bootproduct.model;

public class ResponseData {
	private String message;
	private Long timeStamp;
	
	
	
	
	public ResponseData(String message, long timeStamp) {
		
		this.message = message;
		this.timeStamp = timeStamp;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Long getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Long timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	
}
