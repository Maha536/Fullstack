import { Component, OnInit } from '@angular/core';
import { UserAuthService } from 'src/app/services/authenications/user-auth.service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { registerLocaleData } from '@angular/common';
import { UserserviceService } from 'src/app/services/DataServices/userservice.service';
import { User } from 'src/app/models/user.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  regname : string;
  regmail : string;
  regpass : string;
  regrpass : string;
  dp : any;
  errtext : string='';
  erruser : string='';
  errmail : string='';
  myFormGroup : FormGroup;
  userlist : Array<User>;
  constructor(public auth : UserAuthService,formbuilder : FormBuilder,public ser : UserserviceService,public router:Router) {

    this.myFormGroup=formbuilder.group({
      "username" : new FormControl("",[Validators.required]),
      "uemail" : new FormControl("",[Validators.required, Validators.email]),
      "password1" : new FormControl("", [Validators.required]),
      "password2" : new FormControl("", [Validators.required]),
      "profile" : new FormControl("", [Validators.required])
    });
    
   }
   //checking whether username is available or not
   checkUserName(){
    this.regname = this.myFormGroup.controls['username'].value;
     for(let u of this.userlist){
       //console.log(u.username);
       //console.log(u.uemail);
       //console.log(u.password);
       //console.log(u.profile);
        if(this.regname == u.username){
          this.erruser = "Already exist!!" ;
          break;
        }else{
          this.erruser = "Success" ;
        }
     }
   }
   //checking mailid is already available or not
   checkEmail(){
    this.regmail = this.myFormGroup.controls['uemail'].value;
    console.log(this.regmail)
    for(let u of this.userlist){
      //console.log(u.username);
      //console.log(u.uemail);
      //console.log(u.password);
      //console.log(u.profile);
       if(this.regmail == u.uemail){
         this.errmail = "Already exist!!" ;
         break;
       }
    }

   }

   //checking whether  passwords are matched or not
   checkPassword(){
    this.regpass = this.myFormGroup.controls['password1'].value;
    this.regrpass = this.myFormGroup.controls['password2'].value;
    if (this.regpass === this.regrpass){
      
      this.errtext = "";
    }
    else{
     this.errtext = "Password not matched";
    }
   }

   //registering the user
   register(){
     this.dp =  this.myFormGroup.controls['profile'].value;
     console.log(this.regname);
     console.log(this.regmail)
     console.log(this.regpass);
     console.log(this.dp)
     //saving into database
     let creatuser=new User(this.regname,this.regmail,this.regpass,this.dp);
     this.ser.addUser(creatuser).subscribe((responce:any)=>alert("Account created successfully...."));

     //resetting
     this.regname='';
     this.regmail='';
     this.regpass='';
     this.regrpass='';
     this.dp='';

     this.router.navigate(['/login']);
     
  }

  ngOnInit() {
    this.ser.getAllUsers().subscribe((responce:any)=>{this.userlist=responce;console.log(responce)});
    

  }

}
