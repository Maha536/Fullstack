import { Component, OnInit } from '@angular/core';
import { UserAuthService } from 'src/app/services/authenications/user-auth.service';
import { User } from 'src/app/models/user.model';
import { UserserviceService } from 'src/app/services/DataServices/userservice.service';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-account-update',
  templateUrl: './account-update.component.html',
  styleUrls: ['./account-update.component.css']
})
export class AccountUpdateComponent implements OnInit {
  user : User;
  id : number;
  regname : string;
  regmail : string;
  regpass : string;
  regrpass : string;
  myFormGroup : FormGroup;
  userlist : Array<User>;
  erruser : string ='';
  errpass : string;
  constructor(public auth:UserAuthService,public ser :UserserviceService,public formBuilder:FormBuilder,public router : Router) {
    this.myFormGroup=formBuilder.group({
      "username" : new FormControl(""),
      "uemail" : new FormControl(""),
      "password1" : new FormControl(""),
      "password2" : new FormControl(""),
      
    });
   }
/*
   checkUserName(){
    this.regname = this.myFormGroup.controls['username'].value;
     for(let u of this.userlist){
       //console.log(u.username);
       //console.log(u.uemail);
       //console.log(u.password);
       //console.log(u.profile);
       if(u.id === this.id)
        sessionStorage.setItem("url",u.profile)
        
        if(this.regname == u.username){
          this.erruser = "Already exist!!" ;
          break;
        }else{
          this.erruser = "Success" ;
        }
     }
   }
*/

   checkPassword(){
    this.regpass = this.myFormGroup.controls['password1'].value;
    this.regrpass = this.myFormGroup.controls['password2'].value;
    if (this.regpass === this.regrpass){
      
      this.errpass = "";
    }
    else{
     this.errpass = "Password not matched";
    }
   }

   
   update(){
    this.regname = this.myFormGroup.controls['username'].value;
    this.regmail=this.myFormGroup.controls['uemail'].value;
    this.regpass = this.myFormGroup.controls['password1'].value;
    this.regrpass = this.myFormGroup.controls['password2'].value;
    let url = sessionStorage.getItem("url");
     console.log(this.regname+" "+this.regmail+" "+this.regpass+" "+this.regrpass);
     let userupdated = new User(this.user.username,this.user.uemail,this.regpass,this.user.profile)
     this.ser.update(this.id,userupdated).subscribe((responce)=>{alert("updated successfully");
     this.router.navigate(['/account'])});
   }

  ngOnInit() {
    this.id = this.auth.getId();
    this.ser.getUser(this.id).subscribe((responce)=>this.user=responce);
    //this.ser.getAllUsers().subscribe((responce)=>this.userlist=responce);
  }

}
