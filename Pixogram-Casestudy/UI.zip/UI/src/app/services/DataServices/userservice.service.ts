import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from 'src/app/models/user.model';
const BasicURL = "http://localhost:3000/users";
@Injectable({
  providedIn: 'root'
})


export class UserserviceService {

  constructor(public http : HttpClient) {


   }

  getAllUsers():any{
    return this.http.get(BasicURL);
  }

  getUser(id:number):any{
    return this.http.get(BasicURL+"/"+id);
  }

  addUser(user:User):any{
    return this.http.post(BasicURL,user);
  }

  delete(id:number){
    this.http.delete(BasicURL+"/"+id);
  }

  update(id:number,user:User):any{
    return this.http.put(BasicURL+"/"+id,user);
  }
}
