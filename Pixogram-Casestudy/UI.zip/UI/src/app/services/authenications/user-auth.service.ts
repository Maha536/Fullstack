import { Injectable } from '@angular/core';
import { UserserviceService } from '../DataServices/userservice.service';
import { User } from 'src/app/models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {
  Id : number ;
  userlist : Array<User>;
  constructor(public ser : UserserviceService) { 
    this.ser.getAllUsers().subscribe((responce:any)=>{this.userlist=responce;console.log(responce)});
  }
  
  authenticate(userid : string, password : string): boolean{
    for(let u of this.userlist){
      if(userid === u.uemail && password === u.password){
        sessionStorage.setItem("user", u.username);
        sessionStorage.setItem("uid",String(u.id) );
        console.log("authentication="+this.Id)
        return true;
      }
    }
      return false;
  }

  isUserLoggedIn(): boolean{
    let user = sessionStorage.getItem('user');
    if(user == null)
      return false;
    return true;  
  }
  getId():number{
    let a = Number(sessionStorage.getItem('uid'));
    console.log("in getid"+this.Id)
    return a;
  }

  
  logout(){
    
    sessionStorage.removeItem('user');
    sessionStorage.removeItem('uid');
    
  }

  getUserDetails():string{
    let user = sessionStorage.getItem('user');
    return user;
  }
  
}
