export class User{
    id : number;
    username : string;
    uemail : string;
    password : string;
    profile : any;

    constructor(username,uemail,password,profile){
        this.username =  username;
        this.uemail = uemail;
        this.password = password;
        this.profile = profile;
    }
}