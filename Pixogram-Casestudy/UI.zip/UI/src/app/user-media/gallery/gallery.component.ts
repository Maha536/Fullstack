import { Component, OnInit } from '@angular/core';
import { MediaserviceService } from 'src/app/services/mediaservices/mediaservice.service';
import { Media } from 'src/app/models/media.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {
  fileslist : Array<Media>;
  constructor(public mservice : MediaserviceService,public router:Router) {

   }

   getDetails(id : number){
     console.log(id);
     this.router.navigate(['/media-details/'+id])

   }

  ngOnInit() {
    this.mservice.getAllMedia().subscribe((responce)=>this.fileslist=responce);
  }

}
